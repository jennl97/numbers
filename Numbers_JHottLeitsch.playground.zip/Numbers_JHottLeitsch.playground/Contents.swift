//: Playground - noun: a place where people can play

import UIKit

var one = 1
var two = 90
var three = 3
var four = 4
var five = 5
let six = 6
let seven = 7
let eight = 8
let nine = 9
let ten = 11


var numbers: [Int] = [one, two, three, four, five, six, seven, eight, nine, ten]

numbers = numbers.sort {$0 > $1}

print(numbers)

var numbersDictionary: [String:Int] = [:]

numbersDictionary ["one"] = one
numbersDictionary ["two"] = two
numbersDictionary ["three"] = three
numbersDictionary ["four"] = four
numbersDictionary ["five"] = five
numbersDictionary ["six"] = six
numbersDictionary ["seven"] = seven
numbersDictionary ["eight"] = eight
numbersDictionary ["nine"] = nine
numbersDictionary ["ten"] = ten

print (numbersDictionary)
print (numbersDictionary["ten"])
